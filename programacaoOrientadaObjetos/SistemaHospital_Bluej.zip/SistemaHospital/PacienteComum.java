public class PacienteComum extends Paciente{
    public PacienteComum(String nome, int rg, int idade, int idProntuario){
        super(nome, rg, idade, idProntuario);
    }
}
